import os

GITHUB_USERNAME = "creative-h"
REPO_NAME = "agentQ_Travel_Planner"
ACCESS_TOKEN = "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"

REMOTE_URL = f"https://{ACCESS_TOKEN}@github.com/{GITHUB_USERNAME}/{REPO_NAME}.git"

# Init, commit, and push
# os.system("git init")
# os.system('git config --global user.email "you@example.com"')
# os.system('git config --global user.name "Your Name"')
os.system("git add .")
os.system('git commit -m "Initial commit"')
os.system("git branch -M main")
os.system(f"git remote add origin {REMOTE_URL}")
os.system("git push -u origin main")

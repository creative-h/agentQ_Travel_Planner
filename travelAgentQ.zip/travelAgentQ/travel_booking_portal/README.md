# Travel Package Booking Portal

An intelligent travel package booking portal that combines flights and hotels to create comprehensive travel packages. The system uses Agent Q architecture for reference and integrates with Amadeus API for travel data and Groq API for AI-powered recommendations.

## Features

- **Natural Language Search**: Describe your trip in natural language, and the system will extract search criteria
- **Multi-Destination Support**: Plan trips with multiple destinations and stays
- **AI-Powered Recommendations**: Get personalized recommendations based on your preferences
- **Comprehensive Package Creation**: Automatically combines flights and hotels to create complete travel packages
- **Best Deal Finding**: Identifies the best deals across multiple airlines and hotel providers
- **Interactive Web Interface**: User-friendly Gradio interface for easy interaction

## Project Structure

```
travel_booking_portal/
├── api/                  # API modules for flights, hotels, and packages
│   ├── __init__.py
│   ├── flight_api.py     # Flight search and booking API
│   ├── hotel_api.py      # Hotel search and booking API
│   └── package_api.py    # Package creation and management API
├── utils/                # Utility modules
│   ├── __init__.py
│   ├── agent.py          # AI agent for recommendations
│   ├── config.py         # Configuration management
│   └── data_processor.py # Data processing utilities
├── frontend/             # Frontend interface
│   └── app.py            # Gradio web interface
├── data/                 # Data storage (if needed)
├── main.py               # Main entry point
├── travel_booking_notebook.ipynb  # Jupyter notebook version
├── requirements.txt      # Dependencies
└── README.md             # Documentation
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   cd travel_booking_portal
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   Create a `.env` file in the root directory with the following variables:
   ```
   AMADEUS_API_KEY=your_amadeus_api_key
   AMADEUS_API_SECRET=your_amadeus_api_secret
   GROQ_API_KEY=your_groq_api_key
   GROQ_MODEL=llama3-8b-8192
   DEBUG_MODE=False
   LOG_LEVEL=INFO
   ```

## Usage

### Running the Web Interface

```
python main.py
```

Optional arguments:
- `--env-file`: Path to custom .env file
- `--debug`: Enable debug mode
- `--port`: Port to run the server on (default: 7860)
- `--host`: Host to run the server on (default: 0.0.0.0)
- `--share`: Create a public URL

### Using the Jupyter Notebook

Open and run the `travel_booking_notebook.ipynb` file in Jupyter:

```
jupyter notebook travel_booking_notebook.ipynb
```

Make sure to set your API credentials in the notebook.

## API Credentials

To use this application, you'll need to obtain API credentials from:

1. **Amadeus API** (for flight and hotel data):
   - Sign up at [Amadeus for Developers](https://developers.amadeus.com/)
   - Create a new application to get your API key and secret

2. **Groq API** (for AI-powered recommendations):
   - Sign up at [Groq Console](https://console.groq.com/)
   - Create an API key

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Based on Agent Q architecture
- Uses Amadeus API for travel data
- Uses Groq API for AI-powered recommendations
- Built with Gradio for the user interface

"""
Flight API Module - Handles interactions with flight booking APIs
"""
import logging
from datetime import datetime
from amadeus import Client, ResponseError
from typing import Dict, List, Optional, Any, Union

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('flight_api')

class FlightAPI:
    """
    Flight API class to handle interactions with Amadeus flight booking API
    """
    def __init__(self, api_key: str, api_secret: str):
        """
        Initialize FlightAPI with Amadeus credentials
        
        Args:
            api_key: Amadeus API key
            api_secret: Amadeus API secret
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.client = Client(
            client_id=api_key,
            client_secret=api_secret
        )
        logger.info("FlightAPI initialized with Amadeus client")
    
    def search_flights(self, 
                      origin_location_code: str, 
                      destination_location_code: str, 
                      departure_date: str,
                      return_date: Optional[str] = None, 
                      adults: int = 1, 
                      children: Optional[int] = None, 
                      infants: Optional[int] = None, 
                      travel_class: Optional[str] = None,
                      included_airline_codes: Optional[str] = None, 
                      excluded_airline_codes: Optional[str] = None, 
                      non_stop: str = "false",
                      currency_code: Optional[str] = None, 
                      max_price: Optional[str] = None, 
                      max_results: int = 10) -> List[Dict[str, Any]]:
        """
        Search for flight offers using Amadeus API
        
        Args:
            origin_location_code: IATA code of origin airport/city
            destination_location_code: IATA code of destination airport/city
            departure_date: Departure date in YYYY-MM-DD format
            return_date: Return date in YYYY-MM-DD format (optional)
            adults: Number of adult passengers
            children: Number of child passengers (optional)
            infants: Number of infant passengers (optional)
            travel_class: Travel class (ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST) (optional)
            included_airline_codes: Comma-separated list of airline codes to include (optional)
            excluded_airline_codes: Comma-separated list of airline codes to exclude (optional)
            non_stop: Whether to search for non-stop flights only ("true" or "false")
            currency_code: Currency code for prices (optional)
            max_price: Maximum price (optional)
            max_results: Maximum number of results to return
            
        Returns:
            List of flight offers
        """
        # Set up parameters for the request
        params = {
            'originLocationCode': origin_location_code,
            'destinationLocationCode': destination_location_code,
            'departureDate': departure_date,
            'adults': adults,
            'returnDate': return_date,
            'children': children,
            'infants': infants,
            'travelClass': travel_class,
            'includedAirlineCodes': included_airline_codes,
            'excludedAirlineCodes': excluded_airline_codes,
            'nonStop': non_stop,
            'currencyCode': currency_code,
            'maxPrice': max_price,
            'max': max_results
        }
        
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        logger.info(f"Searching flights with parameters: {params}")
        
        try:
            response = self.client.shopping.flight_offers_search.get(**params)
            logger.info(f"Found {len(response.data)} flight offers")
            return response.data
        except ResponseError as error:
            logger.error(f"Error searching flights: {error}")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.description}")
            if hasattr(error, 'response'):
                logger.error(f"Full error response: {error.response.body}")
            return []
    
    def search_multi_city_flights(self, 
                                 origin_destinations: List[Dict[str, str]], 
                                 adults: int = 1, 
                                 children: Optional[int] = None, 
                                 infants: Optional[int] = None, 
                                 travel_class: Optional[str] = None,
                                 included_airline_codes: Optional[str] = None, 
                                 excluded_airline_codes: Optional[str] = None, 
                                 non_stop: str = "false",
                                 currency_code: Optional[str] = None, 
                                 max_price: Optional[str] = None, 
                                 max_results: int = 10) -> List[Dict[str, Any]]:
        """
        Search for multi-city flight offers using Amadeus API
        
        Args:
            origin_destinations: List of dictionaries with originLocationCode, destinationLocationCode, and departureDate
            adults: Number of adult passengers
            children: Number of child passengers (optional)
            infants: Number of infant passengers (optional)
            travel_class: Travel class (ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST) (optional)
            included_airline_codes: Comma-separated list of airline codes to include (optional)
            excluded_airline_codes: Comma-separated list of airline codes to exclude (optional)
            non_stop: Whether to search for non-stop flights only ("true" or "false")
            currency_code: Currency code for prices (optional)
            max_price: Maximum price (optional)
            max_results: Maximum number of results to return
            
        Returns:
            List of flight offers
        """
        # Set up parameters for the request
        params = {
            'originDestinations': origin_destinations,
            'travelers': [{'id': i+1, 'travelerType': 'ADULT'} for i in range(adults)],
            'sources': ['GDS'],
            'searchCriteria': {
                'maxFlightOffers': max_results,
                'flightFilters': {
                    'nonStop': non_stop == "true"
                }
            }
        }
        
        # Add optional parameters
        if children:
            for i in range(children):
                params['travelers'].append({'id': len(params['travelers'])+1, 'travelerType': 'CHILD'})
        
        if infants:
            for i in range(infants):
                params['travelers'].append({'id': len(params['travelers'])+1, 'travelerType': 'INFANT'})
        
        if travel_class:
            params['searchCriteria']['flightFilters']['cabinRestrictions'] = [{'cabin': travel_class, 'coverage': 'MOST_SEGMENTS', 'originDestinationIds': [str(i+1) for i in range(len(origin_destinations))]}]
        
        if included_airline_codes:
            params['searchCriteria']['flightFilters']['carrierRestrictions'] = {'includedCarrierCodes': included_airline_codes.split(',')}
        
        if excluded_airline_codes:
            if 'carrierRestrictions' not in params['searchCriteria']['flightFilters']:
                params['searchCriteria']['flightFilters']['carrierRestrictions'] = {}
            params['searchCriteria']['flightFilters']['carrierRestrictions']['excludedCarrierCodes'] = excluded_airline_codes.split(',')
        
        if currency_code:
            params['currencyCode'] = currency_code
        
        if max_price:
            params['maxPrice'] = max_price
        
        logger.info(f"Searching multi-city flights with parameters: {params}")
        
        try:
            response = self.client.shopping.flight_offers_search.post(params)
            logger.info(f"Found {len(response.data)} flight offers")
            return response.data
        except ResponseError as error:
            logger.error(f"Error searching multi-city flights: {error}")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.description}")
            if hasattr(error, 'response'):
                logger.error(f"Full error response: {error.response.body}")
            return []
    
    def get_flight_price(self, flight_offer: Dict[str, Any]) -> Dict[str, Any]:
        """
        Get the price for a specific flight offer
        
        Args:
            flight_offer: Flight offer to price
            
        Returns:
            Priced flight offer
        """
        try:
            response = self.client.shopping.flight_offers.pricing.post(
                flight_offers=[flight_offer]
            )
            logger.info("Successfully retrieved flight price")
            return response.data
        except ResponseError as error:
            logger.error(f"Error getting flight price: {error}")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.description}")
            if hasattr(error, 'response'):
                logger.error(f"Full error response: {error.response.body}")
            return {}

"""
Hotel API Module - Handles interactions with hotel booking APIs
"""
import logging
from datetime import datetime
from amadeus import Client, ResponseError
from typing import Dict, List, Optional, Any, Union

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('hotel_api')

class HotelAPI:
    """
    Hotel API class to handle interactions with Amadeus hotel booking API
    """
    def __init__(self, api_key: str, api_secret: str):
        """
        Initialize HotelAPI with Amadeus credentials
        
        Args:
            api_key: Amadeus API key
            api_secret: Amadeus API secret
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.client = Client(
            client_id=api_key,
            client_secret=api_secret
        )
        logger.info("HotelAPI initialized with Amadeus client")
    
    def search_hotels(self, 
                     city_code: str, 
                     check_in_date: str, 
                     check_out_date: str,
                     adults: int = 1,
                     radius: int = 5,
                     radius_unit: str = "KM",
                     hotel_name: Optional[str] = None,
                     chains: Optional[List[str]] = None,
                     ratings: Optional[List[str]] = None,
                     amenities: Optional[List[str]] = None,
                     price_range: Optional[str] = None,
                     currency: Optional[str] = None,
                     lang: str = "EN",
                     max_results: int = 10) -> List[Dict[str, Any]]:
        """
        Search for hotels using Amadeus API
        
        Args:
            city_code: IATA city code
            check_in_date: Check-in date in YYYY-MM-DD format
            check_out_date: Check-out date in YYYY-MM-DD format
            adults: Number of adults
            radius: Radius around the city center in kilometers
            radius_unit: Unit of radius (KM or MILE)
            hotel_name: Name of the hotel (optional)
            chains: List of hotel chain codes (optional)
            ratings: List of hotel ratings (optional)
            amenities: List of amenity codes (optional)
            price_range: Price range in format min-max (optional)
            currency: Currency code (optional)
            lang: Language code
            max_results: Maximum number of results to return
            
        Returns:
            List of hotel offers
        """
        # Set up parameters for the request
        params = {
            'cityCode': city_code,
            'checkInDate': check_in_date,
            'checkOutDate': check_out_date,
            'adults': adults,
            'radius': radius,
            'radiusUnit': radius_unit,
            'hotelName': hotel_name,
            'chainCodes': chains,
            'ratings': ratings,
            'amenities': amenities,
            'priceRange': price_range,
            'currency': currency,
            'lang': lang,
            'max': max_results
        }
        
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        logger.info(f"Searching hotels with parameters: {params}")
        
        try:
            response = self.client.shopping.hotel_offers.get(**params)
            logger.info(f"Found {len(response.data)} hotel offers")
            return response.data
        except ResponseError as error:
            logger.error(f"Error searching hotels: {error}")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.description}")
            if hasattr(error, 'response'):
                logger.error(f"Full error response: {error.response.body}")
            return []
    
    def search_hotel_by_geocode(self, 
                              latitude: float, 
                              longitude: float, 
                              check_in_date: str, 
                              check_out_date: str,
                              adults: int = 1,
                              radius: int = 5,
                              radius_unit: str = "KM",
                              hotel_name: Optional[str] = None,
                              chains: Optional[List[str]] = None,
                              ratings: Optional[List[str]] = None,
                              amenities: Optional[List[str]] = None,
                              price_range: Optional[str] = None,
                              currency: Optional[str] = None,
                              lang: str = "EN",
                              max_results: int = 10) -> List[Dict[str, Any]]:
        """
        Search for hotels using geocode (latitude and longitude) using Amadeus API
        
        Args:
            latitude: Latitude of the location
            longitude: Longitude of the location
            check_in_date: Check-in date in YYYY-MM-DD format
            check_out_date: Check-out date in YYYY-MM-DD format
            adults: Number of adults
            radius: Radius around the location in kilometers
            radius_unit: Unit of radius (KM or MILE)
            hotel_name: Name of the hotel (optional)
            chains: List of hotel chain codes (optional)
            ratings: List of hotel ratings (optional)
            amenities: List of amenity codes (optional)
            price_range: Price range in format min-max (optional)
            currency: Currency code (optional)
            lang: Language code
            max_results: Maximum number of results to return
            
        Returns:
            List of hotel offers
        """
        # Set up parameters for the request
        params = {
            'latitude': latitude,
            'longitude': longitude,
            'checkInDate': check_in_date,
            'checkOutDate': check_out_date,
            'adults': adults,
            'radius': radius,
            'radiusUnit': radius_unit,
            'hotelName': hotel_name,
            'chainCodes': chains,
            'ratings': ratings,
            'amenities': amenities,
            'priceRange': price_range,
            'currency': currency,
            'lang': lang,
            'max': max_results
        }
        
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        logger.info(f"Searching hotels by geocode with parameters: {params}")
        
        try:
            response = self.client.shopping.hotel_offers_by_hotel.get(**params)
            logger.info(f"Found {len(response.data)} hotel offers")
            return response.data
        except ResponseError as error:
            logger.error(f"Error searching hotels by geocode: {error}")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.description}")
            if hasattr(error, 'response'):
                logger.error(f"Full error response: {error.response.body}")
            return []
    
    def get_hotel_offer(self, offer_id: str) -> Dict[str, Any]:
        """
        Get details of a specific hotel offer
        
        Args:
            offer_id: ID of the hotel offer
            
        Returns:
            Hotel offer details
        """
        try:
            response = self.client.shopping.hotel_offer(offer_id).get()
            logger.info(f"Successfully retrieved hotel offer with ID {offer_id}")
            return response.data
        except ResponseError as error:
            logger.error(f"Error getting hotel offer: {error}")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.description}")
            if hasattr(error, 'response'):
                logger.error(f"Full error response: {error.response.body}")
            return {}

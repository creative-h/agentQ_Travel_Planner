"""
Package API Module - Handles creation of travel packages combining flights and hotels
"""
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Tuple
from .flight_api import FlightAPI
from .hotel_api import HotelAPI

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('package_api')

class PackageAPI:
    """
    Package API class to handle creation of travel packages combining flights and hotels
    """
    def __init__(self, flight_api: FlightAPI, hotel_api: HotelAPI):
        """
        Initialize PackageAPI with FlightAPI and HotelAPI instances
        
        Args:
            flight_api: FlightAPI instance
            hotel_api: HotelAPI instance
        """
        self.flight_api = flight_api
        self.hotel_api = hotel_api
        logger.info("PackageAPI initialized with FlightAPI and HotelAPI")
    
    def create_single_destination_package(self, 
                                        origin_location_code: str, 
                                        destination_location_code: str, 
                                        departure_date: str,
                                        return_date: str, 
                                        adults: int = 1, 
                                        children: Optional[int] = None, 
                                        infants: Optional[int] = None, 
                                        travel_class: Optional[str] = None,
                                        hotel_radius: int = 5,
                                        hotel_radius_unit: str = "KM",
                                        hotel_ratings: Optional[List[str]] = None,
                                        currency_code: Optional[str] = None,
                                        max_flight_results: int = 5,
                                        max_hotel_results: int = 5) -> List[Dict[str, Any]]:
        """
        Create a single destination travel package combining flights and hotels
        
        Args:
            origin_location_code: IATA code of origin airport/city
            destination_location_code: IATA code of destination airport/city
            departure_date: Departure date in YYYY-MM-DD format
            return_date: Return date in YYYY-MM-DD format
            adults: Number of adult passengers
            children: Number of child passengers (optional)
            infants: Number of infant passengers (optional)
            travel_class: Travel class (ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST) (optional)
            hotel_radius: Radius around the city center in kilometers
            hotel_radius_unit: Unit of radius (KM or MILE)
            hotel_ratings: List of hotel ratings (optional)
            currency_code: Currency code for prices (optional)
            max_flight_results: Maximum number of flight results to return
            max_hotel_results: Maximum number of hotel results to return
            
        Returns:
            List of travel packages
        """
        # Search for flights
        flight_offers = self.flight_api.search_flights(
            origin_location_code=origin_location_code,
            destination_location_code=destination_location_code,
            departure_date=departure_date,
            return_date=return_date,
            adults=adults,
            children=children,
            infants=infants,
            travel_class=travel_class,
            currency_code=currency_code,
            max_results=max_flight_results
        )
        
        if not flight_offers:
            logger.warning("No flight offers found for the specified criteria")
            return []
        
        # Search for hotels
        hotel_offers = self.hotel_api.search_hotels(
            city_code=destination_location_code,
            check_in_date=departure_date,
            check_out_date=return_date,
            adults=adults,
            radius=hotel_radius,
            radius_unit=hotel_radius_unit,
            ratings=hotel_ratings,
            currency=currency_code,
            max_results=max_hotel_results
        )
        
        if not hotel_offers:
            logger.warning("No hotel offers found for the specified criteria")
            return []
        
        # Create packages by combining flight and hotel offers
        packages = []
        
        for flight_offer in flight_offers:
            for hotel_offer in hotel_offers:
                package = {
                    'flight': flight_offer,
                    'hotel': hotel_offer,
                    'total_price': self._calculate_total_price(flight_offer, hotel_offer),
                    'currency': flight_offer.get('price', {}).get('currency', currency_code or 'USD')
                }
                packages.append(package)
        
        # Sort packages by total price
        packages.sort(key=lambda x: x['total_price'])
        
        logger.info(f"Created {len(packages)} travel packages")
        return packages
    
    def create_multi_destination_package(self, 
                                       itinerary: List[Dict[str, Any]],
                                       adults: int = 1, 
                                       children: Optional[int] = None, 
                                       infants: Optional[int] = None, 
                                       travel_class: Optional[str] = None,
                                       hotel_radius: int = 5,
                                       hotel_radius_unit: str = "KM",
                                       hotel_ratings: Optional[List[str]] = None,
                                       currency_code: Optional[str] = None,
                                       max_flight_results: int = 3,
                                       max_hotel_results: int = 3) -> List[Dict[str, Any]]:
        """
        Create a multi-destination travel package combining flights and hotels
        
        Args:
            itinerary: List of dictionaries with origin, destination, departure_date, and stay_duration
                       Example: [
                           {
                               'origin': 'NYC',
                               'destination': 'PAR',
                               'departure_date': '2023-10-01',
                               'stay_duration': 3
                           },
                           {
                               'origin': 'PAR',
                               'destination': 'ROM',
                               'departure_date': '2023-10-04',
                               'stay_duration': 2
                           },
                           {
                               'origin': 'ROM',
                               'destination': 'NYC',
                               'departure_date': '2023-10-06',
                               'stay_duration': 0
                           }
                       ]
            adults: Number of adult passengers
            children: Number of child passengers (optional)
            infants: Number of infant passengers (optional)
            travel_class: Travel class (ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST) (optional)
            hotel_radius: Radius around the city center in kilometers
            hotel_radius_unit: Unit of radius (KM or MILE)
            hotel_ratings: List of hotel ratings (optional)
            currency_code: Currency code for prices (optional)
            max_flight_results: Maximum number of flight results to return per segment
            max_hotel_results: Maximum number of hotel results to return per destination
            
        Returns:
            List of travel packages
        """
        # Prepare origin-destination data for multi-city flight search
        origin_destinations = []
        for segment in itinerary:
            origin_destinations.append({
                'id': str(len(origin_destinations) + 1),
                'originLocationCode': segment['origin'],
                'destinationLocationCode': segment['destination'],
                'departureDateTimeRange': {
                    'date': segment['departure_date']
                }
            })
        
        # Search for multi-city flights
        flight_offers = self.flight_api.search_multi_city_flights(
            origin_destinations=origin_destinations,
            adults=adults,
            children=children,
            infants=infants,
            travel_class=travel_class,
            currency_code=currency_code,
            max_results=max_flight_results
        )
        
        if not flight_offers:
            logger.warning("No flight offers found for the specified multi-city criteria")
            return []
        
        # Search for hotels at each destination (except the final one if it's the return to origin)
        hotel_offers_by_destination = {}
        
        for i, segment in enumerate(itinerary):
            if segment.get('stay_duration', 0) > 0:
                check_in_date = segment['departure_date']
                check_out_date_obj = datetime.strptime(check_in_date, '%Y-%m-%d') + timedelta(days=segment['stay_duration'])
                check_out_date = check_out_date_obj.strftime('%Y-%m-%d')
                
                hotel_offers = self.hotel_api.search_hotels(
                    city_code=segment['destination'],
                    check_in_date=check_in_date,
                    check_out_date=check_out_date,
                    adults=adults,
                    radius=hotel_radius,
                    radius_unit=hotel_radius_unit,
                    ratings=hotel_ratings,
                    currency=currency_code,
                    max_results=max_hotel_results
                )
                
                if hotel_offers:
                    hotel_offers_by_destination[segment['destination']] = {
                        'offers': hotel_offers,
                        'check_in_date': check_in_date,
                        'check_out_date': check_out_date
                    }
                else:
                    logger.warning(f"No hotel offers found for destination {segment['destination']}")
        
        if not hotel_offers_by_destination:
            logger.warning("No hotel offers found for any destination")
            return []
        
        # Create packages by combining flight and hotel offers
        packages = []
        
        for flight_offer in flight_offers:
            # For each flight offer, create combinations with hotels at each destination
            hotel_combinations = self._generate_hotel_combinations(hotel_offers_by_destination)
            
            for hotel_combination in hotel_combinations:
                total_price = self._calculate_multi_destination_total_price(flight_offer, hotel_combination)
                
                package = {
                    'flight': flight_offer,
                    'hotels': hotel_combination,
                    'total_price': total_price,
                    'currency': flight_offer.get('price', {}).get('currency', currency_code or 'USD')
                }
                packages.append(package)
        
        # Sort packages by total price
        packages.sort(key=lambda x: x['total_price'])
        
        logger.info(f"Created {len(packages)} multi-destination travel packages")
        return packages
    
    def _calculate_total_price(self, flight_offer: Dict[str, Any], hotel_offer: Dict[str, Any]) -> float:
        """
        Calculate the total price of a package
        
        Args:
            flight_offer: Flight offer
            hotel_offer: Hotel offer
            
        Returns:
            Total price
        """
        flight_price = float(flight_offer.get('price', {}).get('total', 0))
        hotel_price = float(hotel_offer.get('offers', [{}])[0].get('price', {}).get('total', 0))
        
        return flight_price + hotel_price
    
    def _calculate_multi_destination_total_price(self, flight_offer: Dict[str, Any], hotels: List[Dict[str, Any]]) -> float:
        """
        Calculate the total price of a multi-destination package
        
        Args:
            flight_offer: Flight offer
            hotels: List of hotel offers
            
        Returns:
            Total price
        """
        flight_price = float(flight_offer.get('price', {}).get('total', 0))
        hotel_price = sum(float(hotel.get('offers', [{}])[0].get('price', {}).get('total', 0)) for hotel in hotels)
        
        return flight_price + hotel_price
    
    def _generate_hotel_combinations(self, hotel_offers_by_destination: Dict[str, Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        """
        Generate all possible combinations of hotels for each destination
        
        Args:
            hotel_offers_by_destination: Dictionary mapping destinations to hotel offers
            
        Returns:
            List of hotel combinations
        """
        # For simplicity, we'll just take the first hotel offer for each destination
        # In a real implementation, this would generate all possible combinations
        combinations = []
        combination = []
        
        for destination, data in hotel_offers_by_destination.items():
            if data['offers']:
                hotel_info = {
                    'destination': destination,
                    'check_in_date': data['check_in_date'],
                    'check_out_date': data['check_out_date'],
                    'offers': [data['offers'][0]]
                }
                combination.append(hotel_info)
        
        combinations.append(combination)
        return combinations
    
    def find_best_deals(self, packages: List[Dict[str, Any]], sort_by: str = 'price', limit: int = 5) -> List[Dict[str, Any]]:
        """
        Find the best deals from a list of packages
        
        Args:
            packages: List of travel packages
            sort_by: Criteria to sort by ('price', 'duration', 'rating')
            limit: Maximum number of deals to return
            
        Returns:
            List of best deals
        """
        if not packages:
            return []
        
        if sort_by == 'price':
            sorted_packages = sorted(packages, key=lambda x: x['total_price'])
        elif sort_by == 'duration':
            # Sort by shortest total flight duration
            sorted_packages = sorted(packages, key=lambda x: self._get_total_flight_duration(x['flight']))
        elif sort_by == 'rating':
            # Sort by highest hotel rating
            sorted_packages = sorted(packages, key=lambda x: self._get_hotel_rating(x.get('hotel', x.get('hotels', [{}])[0])), reverse=True)
        else:
            sorted_packages = packages
        
        return sorted_packages[:limit]
    
    def _get_total_flight_duration(self, flight_offer: Dict[str, Any]) -> int:
        """
        Get the total duration of a flight offer in minutes
        
        Args:
            flight_offer: Flight offer
            
        Returns:
            Total duration in minutes
        """
        try:
            itineraries = flight_offer.get('itineraries', [])
            total_duration = sum(int(itinerary.get('duration', '0').replace('PT', '').replace('H', '').replace('M', '')) for itinerary in itineraries)
            return total_duration
        except Exception as e:
            logger.error(f"Error calculating flight duration: {e}")
            return 0
    
    def _get_hotel_rating(self, hotel_offer: Dict[str, Any]) -> float:
        """
        Get the rating of a hotel offer
        
        Args:
            hotel_offer: Hotel offer
            
        Returns:
            Hotel rating
        """
        try:
            hotel = hotel_offer.get('hotel', {})
            rating = hotel.get('rating', 0)
            return float(rating)
        except Exception as e:
            logger.error(f"Error getting hotel rating: {e}")
            return 0

"""
Gradio frontend for travel package booking portal
"""
import os
import sys
import json
import logging
import gradio as gr
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Tuple

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils import Config, TravelAgent, DataProcessor
from api import FlightAPI, HotelAPI, PackageAPI

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('frontend')

# Load configuration
config = Config()
if not config.validate():
    logger.error("Invalid configuration. Please check your environment variables.")
    sys.exit(1)

# Initialize APIs
amadeus_credentials = config.get_amadeus_credentials()
flight_api = FlightAPI(amadeus_credentials['api_key'], amadeus_credentials['api_secret'])
hotel_api = HotelAPI(amadeus_credentials['api_key'], amadeus_credentials['api_secret'])
package_api = PackageAPI(flight_api, hotel_api)

# Initialize agent
groq_credentials = config.get_groq_credentials()
travel_agent = TravelAgent(groq_credentials['api_key'], groq_credentials['model'])

# Initialize data processor
data_processor = DataProcessor()

# Global variables to store search results
current_packages = []
current_flights = []
current_hotels = []
current_criteria = {}

def natural_language_search(query: str) -> Tuple[str, gr.Dropdown, gr.Dropdown, gr.Dropdown, gr.Dropdown, gr.Textbox, gr.Textbox, gr.Dropdown, gr.Dropdown, gr.Slider, gr.Checkbox]:
    """
    Process natural language search query
    
    Args:
        query: Natural language query
        
    Returns:
        Response message and updated UI components
    """
    global current_criteria
    
    # Extract travel criteria from query
    criteria = travel_agent.extract_travel_criteria(query)
    current_criteria = criteria
    
    # Prepare response
    response = f"I understand you're looking for a trip with the following details:\n\n"
    
    if 'origin_location' in criteria and criteria['origin_location']:
        response += f"- Departing from: {criteria['origin_location']}\n"
        
    if 'destinations' in criteria and criteria['destinations']:
        if isinstance(criteria['destinations'], list):
            response += f"- Destinations: {', '.join(criteria['destinations'])}\n"
        else:
            response += f"- Destination: {criteria['destinations']}\n"
            
    if 'departure_date' in criteria and criteria['departure_date']:
        response += f"- Departure date: {criteria['departure_date']}\n"
        
    if 'return_date' in criteria and criteria['return_date']:
        response += f"- Return date: {criteria['return_date']}\n"
        
    if 'adults' in criteria and criteria['adults']:
        response += f"- Adults: {criteria['adults']}\n"
        
    if 'children' in criteria and criteria['children']:
        response += f"- Children: {criteria['children']}\n"
        
    if 'travel_class' in criteria and criteria['travel_class']:
        response += f"- Travel class: {criteria['travel_class']}\n"
        
    if 'budget' in criteria and criteria['budget']:
        response += f"- Budget: {criteria['budget']}\n"
        
    if 'preferences' in criteria and criteria['preferences']:
        if isinstance(criteria['preferences'], list):
            response += f"- Preferences: {', '.join(criteria['preferences'])}\n"
        else:
            response += f"- Preferences: {criteria['preferences']}\n"
    
    response += "\nPlease confirm these details or adjust them using the form below. Then click 'Search Packages' to find the best deals."
    
    # Update UI components with extracted criteria
    origin = criteria.get('origin_location', '')
    
    if isinstance(criteria.get('destinations', ''), list):
        destination = criteria['destinations'][0] if criteria['destinations'] else ''
    else:
        destination = criteria.get('destinations', '')
    
    departure_date = criteria.get('departure_date', datetime.now().strftime('%Y-%m-%d'))
    return_date = criteria.get('return_date', (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d'))
    
    adults = criteria.get('adults', 1)
    children = criteria.get('children', 0)
    
    travel_class = criteria.get('travel_class', 'ECONOMY')
    travel_class_dropdown = gr.Dropdown(choices=["ECONOMY", "PREMIUM_ECONOMY", "BUSINESS", "FIRST"], value=travel_class)
    
    budget = criteria.get('budget', '')
    
    multi_destination = criteria.get('multi_destination', False)
    
    # Return response and updated UI components
    return (
        response,
        gr.Dropdown(value=origin),
        gr.Dropdown(value=destination),
        gr.Dropdown(value=departure_date),
        gr.Dropdown(value=return_date),
        gr.Textbox(value=str(adults)),
        gr.Textbox(value=str(children) if children else "0"),
        travel_class_dropdown,
        gr.Dropdown(value=budget),
        gr.Slider(value=5),
        gr.Checkbox(value=multi_destination)
    )

def search_packages(
    origin: str,
    destination: str,
    departure_date: str,
    return_date: str,
    adults: str,
    children: str,
    travel_class: str,
    budget: str,
    hotel_rating: float,
    multi_destination: bool
) -> Tuple[str, gr.Dataframe, gr.Dataframe, gr.Dataframe]:
    """
    Search for travel packages
    
    Args:
        origin: Origin location code
        destination: Destination location code
        departure_date: Departure date
        return_date: Return date
        adults: Number of adults
        children: Number of children
        travel_class: Travel class
        budget: Maximum budget
        hotel_rating: Minimum hotel rating
        multi_destination: Whether this is a multi-destination trip
        
    Returns:
        Response message and dataframes with search results
    """
    global current_packages, current_flights, current_hotels, current_criteria
    
    # Validate inputs
    if not origin or not destination:
        return "Please provide both origin and destination locations.", None, None, None
    
    try:
        adults_count = int(adults)
    except ValueError:
        adults_count = 1
    
    try:
        children_count = int(children) if children else 0
    except ValueError:
        children_count = 0
    
    # Update current criteria
    current_criteria.update({
        'origin_location': origin,
        'destinations': destination,
        'departure_date': departure_date,
        'return_date': return_date,
        'adults': adults_count,
        'children': children_count,
        'travel_class': travel_class,
        'budget': budget,
        'min_hotel_rating': hotel_rating,
        'multi_destination': multi_destination
    })
    
    # Search for packages
    if not multi_destination:
        # Single destination package
        packages = package_api.create_single_destination_package(
            origin_location_code=origin,
            destination_location_code=destination,
            departure_date=departure_date,
            return_date=return_date,
            adults=adults_count,
            children=children_count,
            travel_class=travel_class,
            hotel_ratings=[str(int(hotel_rating))] if hotel_rating > 0 else None,
            currency_code="USD"
        )
    else:
        # For simplicity, we'll just support a simple multi-destination trip
        # In a real app, you would have a more complex UI for defining multiple destinations
        itinerary = [
            {
                'origin': origin,
                'destination': destination,
                'departure_date': departure_date,
                'stay_duration': 3
            },
            {
                'origin': destination,
                'destination': origin,
                'departure_date': return_date,
                'stay_duration': 0
            }
        ]
        
        packages = package_api.create_multi_destination_package(
            itinerary=itinerary,
            adults=adults_count,
            children=children_count,
            travel_class=travel_class,
            hotel_ratings=[str(int(hotel_rating))] if hotel_rating > 0 else None,
            currency_code="USD"
        )
    
    # Filter packages by budget if provided
    if budget:
        try:
            max_price = float(budget)
            packages = [p for p in packages if p['total_price'] <= max_price]
        except ValueError:
            pass
    
    # Store search results
    current_packages = packages
    
    # Extract flights and hotels from packages
    if packages:
        flight_offers = [p['flight'] for p in packages]
        current_flights = flight_offers
        
        if not multi_destination:
            hotel_offers = [p['hotel'] for p in packages]
        else:
            # Flatten hotel offers from all destinations
            hotel_offers = []
            for p in packages:
                for hotel in p.get('hotels', []):
                    hotel_offers.append(hotel)
        
        current_hotels = hotel_offers
        
        # Parse data into dataframes
        packages_df = data_processor.parse_package_data(packages)
        flights_df = data_processor.parse_flight_data(flight_offers)
        hotels_df = data_processor.parse_hotel_data(hotel_offers)
        
        # Generate recommendations
        recommendations = travel_agent.generate_travel_recommendations(packages[:3], current_criteria)
        
        return recommendations, packages_df, flights_df, hotels_df
    else:
        return "No packages found matching your criteria. Please try adjusting your search parameters.", None, None, None

def view_package_details(package_id: int) -> str:
    """
    View details of a specific package
    
    Args:
        package_id: ID of the package to view
        
    Returns:
        Formatted package details
    """
    global current_packages
    
    if not current_packages or package_id >= len(current_packages):
        return "Package not found. Please search for packages first."
    
    package = current_packages[package_id]
    
    # Format package details using the agent
    formatted_details = travel_agent.format_package_details(package, detailed=True)
    
    return formatted_details

def ask_question(question: str) -> str:
    """
    Ask a question about travel
    
    Args:
        question: User's question
        
    Returns:
        Answer to the question
    """
    global current_packages, current_criteria
    
    # Prepare context with current search results and criteria
    context = {
        'current_criteria': current_criteria,
        'has_search_results': len(current_packages) > 0,
        'number_of_packages': len(current_packages),
        'price_range': {
            'min': min([p['total_price'] for p in current_packages]) if current_packages else None,
            'max': max([p['total_price'] for p in current_packages]) if current_packages else None,
            'currency': current_packages[0]['currency'] if current_packages else None
        }
    }
    
    # Get answer from agent
    answer = travel_agent.answer_travel_question(question, context)
    
    return answer

# Create Gradio interface
with gr.Blocks(title="Travel Package Booking Portal") as app:
    gr.Markdown("# Travel Package Booking Portal")
    gr.Markdown("Find the best travel packages with flights and hotels for your next trip!")
    
    with gr.Tab("Natural Language Search"):
        with gr.Row():
            with gr.Column():
                nl_query = gr.Textbox(
                    label="Describe your trip",
                    placeholder="I want to travel from New York to Paris for a week in July with my family (2 adults, 1 child)",
                    lines=3
                )
                nl_search_btn = gr.Button("Process Query")
            
            with gr.Column():
                nl_response = gr.Markdown(label="Response")
        
        with gr.Row():
            with gr.Column():
                origin_input = gr.Dropdown(
                    label="Origin (Airport/City Code)",
                    choices=["NYC", "LAX", "ORD", "LHR", "CDG", "SYD", "HKG", "DXB", "SIN"],
                    value=""
                )
                destination_input = gr.Dropdown(
                    label="Destination (Airport/City Code)",
                    choices=["NYC", "LAX", "PAR", "LON", "ROM", "BCN", "TYO", "BKK", "SYD"],
                    value=""
                )
                departure_date_input = gr.Dropdown(
                    label="Departure Date",
                    choices=[(datetime.now() + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(1, 180, 7)],
                    value=datetime.now().strftime('%Y-%m-%d')
                )
                return_date_input = gr.Dropdown(
                    label="Return Date",
                    choices=[(datetime.now() + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7, 187, 7)],
                    value=(datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d')
                )
            
            with gr.Column():
                adults_input = gr.Textbox(
                    label="Number of Adults",
                    value="1"
                )
                children_input = gr.Textbox(
                    label="Number of Children",
                    value="0"
                )
                travel_class_input = gr.Dropdown(
                    label="Travel Class",
                    choices=["ECONOMY", "PREMIUM_ECONOMY", "BUSINESS", "FIRST"],
                    value="ECONOMY"
                )
                budget_input = gr.Dropdown(
                    label="Budget (USD)",
                    choices=["500", "1000", "1500", "2000", "3000", "5000", "10000"],
                    value=""
                )
                hotel_rating_input = gr.Slider(
                    label="Minimum Hotel Rating",
                    minimum=0,
                    maximum=5,
                    step=1,
                    value=0
                )
                multi_destination_input = gr.Checkbox(
                    label="Multi-Destination Trip",
                    value=False
                )
        
        search_btn = gr.Button("Search Packages")
    
    with gr.Tab("Search Results"):
        with gr.Row():
            recommendations_output = gr.Markdown(label="Recommendations")
        
        with gr.Tabs():
            with gr.TabItem("Packages"):
                packages_output = gr.Dataframe(label="Available Packages")
                package_id_input = gr.Number(label="Package ID", value=0, precision=0)
                view_package_btn = gr.Button("View Package Details")
                package_details_output = gr.Markdown(label="Package Details")
            
            with gr.TabItem("Flights"):
                flights_output = gr.Dataframe(label="Flight Options")
            
            with gr.TabItem("Hotels"):
                hotels_output = gr.Dataframe(label="Hotel Options")
    
    with gr.Tab("Ask a Question"):
        with gr.Row():
            question_input = gr.Textbox(
                label="Your Question",
                placeholder="What's the best time to visit Paris?",
                lines=2
            )
            ask_btn = gr.Button("Ask")
        
        with gr.Row():
            answer_output = gr.Markdown(label="Answer")
    
    # Set up event handlers
    nl_search_btn.click(
        natural_language_search,
        inputs=[nl_query],
        outputs=[
            nl_response,
            origin_input,
            destination_input,
            departure_date_input,
            return_date_input,
            adults_input,
            children_input,
            travel_class_input,
            budget_input,
            hotel_rating_input,
            multi_destination_input
        ]
    )
    
    search_btn.click(
        search_packages,
        inputs=[
            origin_input,
            destination_input,
            departure_date_input,
            return_date_input,
            adults_input,
            children_input,
            travel_class_input,
            budget_input,
            hotel_rating_input,
            multi_destination_input
        ],
        outputs=[
            recommendations_output,
            packages_output,
            flights_output,
            hotels_output
        ]
    )
    
    view_package_btn.click(
        view_package_details,
        inputs=[package_id_input],
        outputs=[package_details_output]
    )
    
    ask_btn.click(
        ask_question,
        inputs=[question_input],
        outputs=[answer_output]
    )

# Launch the app if running directly
if __name__ == "__main__":
    app.launch(share=True)

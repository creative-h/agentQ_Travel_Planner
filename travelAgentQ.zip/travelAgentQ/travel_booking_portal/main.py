"""
Main entry point for travel package booking portal
"""
import os
import sys
import logging
import argparse
from dotenv import load_dotenv

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils import Config
from frontend.app import app as gradio_app

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('main')

def main():
    """
    Main entry point for travel package booking portal
    """
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Travel Package Booking Portal')
    parser.add_argument('--env-file', type=str, help='Path to .env file')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    parser.add_argument('--port', type=int, default=7860, help='Port to run the server on')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='Host to run the server on')
    parser.add_argument('--share', action='store_true', help='Create a public URL')
    args = parser.parse_args()
    
    # Load environment variables
    if args.env_file:
        load_dotenv(args.env_file)
    else:
        load_dotenv()
    
    # Set debug mode
    if args.debug:
        os.environ['DEBUG_MODE'] = 'True'
        logging.basicConfig(level=logging.DEBUG)
        logger.setLevel(logging.DEBUG)
    
    # Load configuration
    config = Config()
    if not config.validate():
        logger.error("Invalid configuration. Please check your environment variables.")
        sys.exit(1)
    
    logger.info("Starting Travel Package Booking Portal")
    
    # Launch Gradio app
    gradio_app.launch(
        server_name=args.host,
        server_port=args.port,
        share=args.share
    )

if __name__ == "__main__":
    main()

"""
Agent module - Handles intelligent recommendations and natural language interactions
"""
import logging
import os
import json
from typing import Dict, List, Optional, Any, Union
from groq import Groq

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('agent')

class TravelAgent:
    """
    Travel Agent class to handle intelligent recommendations and natural language interactions
    """
    def __init__(self, api_key: str, model: str = "llama3-8b-8192"):
        """
        Initialize TravelAgent with Groq API key
        
        Args:
            api_key: Groq API key
            model: Groq model to use
        """
        self.api_key = api_key
        self.model = model
        self.client = Groq(api_key=api_key)
        logger.info(f"TravelAgent initialized with Groq model {model}")
    
    def extract_travel_criteria(self, user_query: str) -> Dict[str, Any]:
        """
        Extract travel criteria from user query
        
        Args:
            user_query: User's natural language query
            
        Returns:
            Dictionary of extracted travel criteria
        """
        prompt = f"""
        Extract travel search criteria from the following user query. 
        Return a JSON object with the following fields (if they can be determined):
        
        - origin_location: The city or airport where the trip starts
        - destinations: A list of destinations (cities or countries)
        - departure_date: When the user wants to leave (YYYY-MM-DD)
        - return_date: When the user wants to return (YYYY-MM-DD)
        - adults: Number of adult travelers
        - children: Number of child travelers
        - infants: Number of infant travelers
        - travel_class: Class of travel (ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST)
        - budget: Maximum budget for the trip
        - preferences: Any specific preferences mentioned (e.g., "non-stop flights", "beach resort")
        - multi_destination: Boolean indicating if this is a multi-destination trip
        
        User Query: {user_query}
        
        JSON Response:
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a travel agent assistant that extracts structured information from user queries."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                max_tokens=1000
            )
            
            result = response.choices[0].message.content.strip()
            logger.info(f"Extracted travel criteria: {result}")
            
            # Extract JSON from the response
            try:
                json_start = result.find('{')
                json_end = result.rfind('}') + 1
                if json_start != -1 and json_end != -1:
                    json_str = result[json_start:json_end]
                    criteria = json.loads(json_str)
                else:
                    criteria = json.loads(result)
                return criteria
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing JSON from response: {e}")
                logger.error(f"Raw response: {result}")
                return {}
                
        except Exception as e:
            logger.error(f"Error extracting travel criteria: {e}")
            return {}
    
    def generate_travel_recommendations(self, packages: List[Dict[str, Any]], user_preferences: Dict[str, Any]) -> str:
        """
        Generate travel recommendations based on available packages and user preferences
        
        Args:
            packages: List of travel packages
            user_preferences: User preferences
            
        Returns:
            Recommendation text
        """
        if not packages:
            return "I couldn't find any travel packages matching your criteria. Please try adjusting your search parameters."
        
        # Format packages for the prompt
        packages_str = json.dumps(packages[:3], indent=2)  # Limit to top 3 for prompt size
        preferences_str = json.dumps(user_preferences, indent=2)
        
        prompt = f"""
        Based on the user's preferences and the available travel packages, provide personalized recommendations.
        
        User Preferences:
        {preferences_str}
        
        Available Packages (top 3 shown):
        {packages_str}
        
        Please provide:
        1. A summary of the best package option and why it matches the user's needs
        2. Alternative options if available
        3. Additional suggestions to enhance their trip
        4. Any important considerations they should be aware of
        
        Format your response in a conversational, helpful manner.
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a knowledgeable travel agent providing personalized recommendations."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1500
            )
            
            result = response.choices[0].message.content.strip()
            logger.info("Generated travel recommendations")
            return result
                
        except Exception as e:
            logger.error(f"Error generating travel recommendations: {e}")
            return "I'm sorry, I encountered an error while generating recommendations. Please try again later."
    
    def answer_travel_question(self, question: str, context: Optional[Dict[str, Any]] = None) -> str:
        """
        Answer a travel-related question
        
        Args:
            question: User's question
            context: Optional context information
            
        Returns:
            Answer to the question
        """
        context_str = json.dumps(context) if context else "{}"
        
        prompt = f"""
        Answer the following travel-related question based on the provided context.
        
        Context:
        {context_str}
        
        Question:
        {question}
        
        Provide a helpful, accurate, and concise answer. If you don't know the answer, say so honestly.
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a knowledgeable travel agent assistant providing helpful information."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.5,
                max_tokens=1000
            )
            
            result = response.choices[0].message.content.strip()
            logger.info("Generated answer to travel question")
            return result
                
        except Exception as e:
            logger.error(f"Error answering travel question: {e}")
            return "I'm sorry, I encountered an error while answering your question. Please try again later."
    
    def format_package_details(self, package: Dict[str, Any], detailed: bool = False) -> str:
        """
        Format package details for display
        
        Args:
            package: Travel package
            detailed: Whether to include detailed information
            
        Returns:
            Formatted package details
        """
        prompt = f"""
        Format the following travel package details in a clear, organized way for a customer.
        
        Package Details:
        {json.dumps(package, indent=2)}
        
        Detailed View: {"Yes" if detailed else "No"}
        
        Format the information in a way that highlights:
        1. Flight details (departure/arrival times, airlines, layovers)
        2. Hotel information (name, rating, amenities)
        3. Total price and what's included
        4. Any special features of this package
        
        Use markdown formatting to make the information easy to read.
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a travel agent assistant that formats complex travel information in a clear, customer-friendly way."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1500
            )
            
            result = response.choices[0].message.content.strip()
            logger.info("Formatted package details")
            return result
                
        except Exception as e:
            logger.error(f"Error formatting package details: {e}")
            return "I'm sorry, I encountered an error while formatting the package details. Please try again later."

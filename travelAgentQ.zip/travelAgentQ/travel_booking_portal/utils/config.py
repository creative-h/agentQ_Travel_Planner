"""
Configuration module for travel booking portal
"""
import os
import logging
from typing import Dict, Any, Optional
from dotenv import load_dotenv

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('config')

class Config:
    """
    Configuration class for travel booking portal
    """
    def __init__(self, env_file: Optional[str] = None):
        """
        Initialize Config with environment variables
        
        Args:
            env_file: Path to .env file (optional)
        """
        # Load environment variables from .env file if provided
        if env_file:
            load_dotenv(env_file)
        else:
            load_dotenv()
        
        # Amadeus API credentials
        self.amadeus_api_key = os.getenv('AMADEUS_API_KEY', '')
        self.amadeus_api_secret = os.getenv('AMADEUS_API_SECRET', '')
        
        # Groq API credentials
        self.groq_api_key = os.getenv('GROQ_API_KEY', '')
        self.groq_model = os.getenv('GROQ_MODEL', 'llama3-8b-8192')
        
        # Application settings
        self.debug_mode = os.getenv('DEBUG_MODE', 'False').lower() == 'true'
        self.log_level = os.getenv('LOG_LEVEL', 'INFO')
        
        # Configure logging level
        numeric_level = getattr(logging, self.log_level.upper(), None)
        if isinstance(numeric_level, int):
            logging.basicConfig(level=numeric_level)
        
        logger.info("Configuration loaded")
    
    def validate(self) -> bool:
        """
        Validate configuration
        
        Returns:
            True if configuration is valid, False otherwise
        """
        if not self.amadeus_api_key or not self.amadeus_api_secret:
            logger.error("Amadeus API credentials not found in environment variables")
            return False
        
        if not self.groq_api_key:
            logger.error("Groq API key not found in environment variables")
            return False
        
        logger.info("Configuration validated successfully")
        return True
    
    def get_amadeus_credentials(self) -> Dict[str, str]:
        """
        Get Amadeus API credentials
        
        Returns:
            Dictionary with Amadeus API credentials
        """
        return {
            'api_key': self.amadeus_api_key,
            'api_secret': self.amadeus_api_secret
        }
    
    def get_groq_credentials(self) -> Dict[str, str]:
        """
        Get Groq API credentials
        
        Returns:
            Dictionary with Groq API credentials
        """
        return {
            'api_key': self.groq_api_key,
            'model': self.groq_model
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary
        
        Returns:
            Dictionary representation of configuration
        """
        return {
            'amadeus_api_key': self.amadeus_api_key,
            'amadeus_api_secret': '***' if self.amadeus_api_secret else None,
            'groq_api_key': '***' if self.groq_api_key else None,
            'groq_model': self.groq_model,
            'debug_mode': self.debug_mode,
            'log_level': self.log_level
        }

"""
Data processor module for travel booking portal
"""
import logging
import json
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('data_processor')

class DataProcessor:
    """
    Data processor class for travel booking portal
    """
    @staticmethod
    def parse_flight_data(flight_offers: List[Dict[str, Any]]) -> pd.DataFrame:
        """
        Parse flight offers data into a pandas DataFrame
        
        Args:
            flight_offers: List of flight offers from Amadeus API
            
        Returns:
            DataFrame with flight data
        """
        if not flight_offers:
            logger.warning("No flight offers to parse")
            return pd.DataFrame()
        
        flight_data = []
        
        for offer in flight_offers:
            offer_id = offer.get('id', '')
            price = float(offer.get('price', {}).get('total', 0))
            currency = offer.get('price', {}).get('currency', '')
            
            for itinerary_idx, itinerary in enumerate(offer.get('itineraries', [])):
                direction = 'Outbound' if itinerary_idx == 0 else 'Inbound'
                
                for segment_idx, segment in enumerate(itinerary.get('segments', [])):
                    departure = segment.get('departure', {})
                    arrival = segment.get('arrival', {})
                    carrier = segment.get('carrierCode', '')
                    flight_number = segment.get('number', '')
                    aircraft = segment.get('aircraft', {}).get('code', '')
                    
                    flight_data.append({
                        'offer_id': offer_id,
                        'price': price,
                        'currency': currency,
                        'direction': direction,
                        'segment_idx': segment_idx,
                        'departure_iata': departure.get('iataCode', ''),
                        'departure_time': departure.get('at', ''),
                        'arrival_iata': arrival.get('iataCode', ''),
                        'arrival_time': arrival.get('at', ''),
                        'carrier': carrier,
                        'flight_number': flight_number,
                        'aircraft': aircraft,
                        'duration': segment.get('duration', '')
                    })
        
        df = pd.DataFrame(flight_data)
        logger.info(f"Parsed {len(df)} flight segments from {len(flight_offers)} offers")
        return df
    
    @staticmethod
    def parse_hotel_data(hotel_offers: List[Dict[str, Any]]) -> pd.DataFrame:
        """
        Parse hotel offers data into a pandas DataFrame
        
        Args:
            hotel_offers: List of hotel offers from Amadeus API
            
        Returns:
            DataFrame with hotel data
        """
        if not hotel_offers:
            logger.warning("No hotel offers to parse")
            return pd.DataFrame()
        
        hotel_data = []
        
        for offer in hotel_offers:
            hotel = offer.get('hotel', {})
            hotel_id = hotel.get('hotelId', '')
            name = hotel.get('name', '')
            rating = hotel.get('rating', '')
            city_code = hotel.get('cityCode', '')
            
            for offer_item in offer.get('offers', []):
                offer_id = offer_item.get('id', '')
                price = float(offer_item.get('price', {}).get('total', 0))
                currency = offer_item.get('price', {}).get('currency', '')
                
                room = offer_item.get('room', {})
                room_type = room.get('type', '')
                room_description = room.get('description', {}).get('text', '')
                
                hotel_data.append({
                    'hotel_id': hotel_id,
                    'offer_id': offer_id,
                    'name': name,
                    'rating': rating,
                    'city_code': city_code,
                    'price': price,
                    'currency': currency,
                    'room_type': room_type,
                    'room_description': room_description
                })
        
        df = pd.DataFrame(hotel_data)
        logger.info(f"Parsed {len(df)} hotel offers")
        return df
    
    @staticmethod
    def parse_package_data(packages: List[Dict[str, Any]]) -> pd.DataFrame:
        """
        Parse travel package data into a pandas DataFrame
        
        Args:
            packages: List of travel packages
            
        Returns:
            DataFrame with package data
        """
        if not packages:
            logger.warning("No packages to parse")
            return pd.DataFrame()
        
        package_data = []
        
        for idx, package in enumerate(packages):
            flight = package.get('flight', {})
            flight_id = flight.get('id', '')
            flight_price = float(flight.get('price', {}).get('total', 0))
            
            if 'hotel' in package:
                # Single destination package
                hotel = package.get('hotel', {})
                hotel_id = hotel.get('hotel', {}).get('hotelId', '')
                hotel_name = hotel.get('hotel', {}).get('name', '')
                hotel_price = float(hotel.get('offers', [{}])[0].get('price', {}).get('total', 0))
                
                package_data.append({
                    'package_id': idx,
                    'total_price': package.get('total_price', 0),
                    'currency': package.get('currency', ''),
                    'flight_id': flight_id,
                    'flight_price': flight_price,
                    'hotel_id': hotel_id,
                    'hotel_name': hotel_name,
                    'hotel_price': hotel_price,
                    'multi_destination': False
                })
            else:
                # Multi-destination package
                hotels = package.get('hotels', [])
                hotel_ids = [h.get('offers', [{}])[0].get('hotel', {}).get('hotelId', '') for h in hotels]
                hotel_names = [h.get('offers', [{}])[0].get('hotel', {}).get('name', '') for h in hotels]
                hotel_prices = [float(h.get('offers', [{}])[0].get('price', {}).get('total', 0)) for h in hotels]
                
                package_data.append({
                    'package_id': idx,
                    'total_price': package.get('total_price', 0),
                    'currency': package.get('currency', ''),
                    'flight_id': flight_id,
                    'flight_price': flight_price,
                    'hotel_ids': json.dumps(hotel_ids),
                    'hotel_names': json.dumps(hotel_names),
                    'hotel_prices': json.dumps(hotel_prices),
                    'multi_destination': True
                })
        
        df = pd.DataFrame(package_data)
        logger.info(f"Parsed {len(df)} travel packages")
        return df
    
    @staticmethod
    def format_duration(duration_str: str) -> str:
        """
        Format duration string
        
        Args:
            duration_str: Duration string in format PT2H30M
            
        Returns:
            Formatted duration string (e.g., "2h 30m")
        """
        if not duration_str or not duration_str.startswith('PT'):
            return duration_str
        
        duration = duration_str[2:]  # Remove 'PT'
        hours = '0'
        minutes = '0'
        
        if 'H' in duration:
            hours, duration = duration.split('H')
        
        if 'M' in duration:
            minutes = duration.replace('M', '')
        
        return f"{hours}h {minutes}m"
    
    @staticmethod
    def format_datetime(datetime_str: str) -> str:
        """
        Format datetime string
        
        Args:
            datetime_str: Datetime string in ISO format
            
        Returns:
            Formatted datetime string (e.g., "Mon, 15 Jun 2023, 14:30")
        """
        if not datetime_str:
            return datetime_str
        
        try:
            dt = datetime.fromisoformat(datetime_str.replace('Z', '+00:00'))
            return dt.strftime("%a, %d %b %Y, %H:%M")
        except ValueError:
            return datetime_str
    
    @staticmethod
    def calculate_layover(arrival_time: str, next_departure_time: str) -> str:
        """
        Calculate layover duration between flights
        
        Args:
            arrival_time: Arrival time in ISO format
            next_departure_time: Next departure time in ISO format
            
        Returns:
            Layover duration string (e.g., "2h 30m")
        """
        if not arrival_time or not next_departure_time:
            return ""
        
        try:
            arrival = datetime.fromisoformat(arrival_time.replace('Z', '+00:00'))
            departure = datetime.fromisoformat(next_departure_time.replace('Z', '+00:00'))
            
            delta = departure - arrival
            hours, remainder = divmod(delta.seconds, 3600)
            minutes, _ = divmod(remainder, 60)
            
            return f"{hours}h {minutes}m"
        except ValueError:
            return ""
    
    @staticmethod
    def filter_packages_by_criteria(packages: List[Dict[str, Any]], criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Filter packages by criteria
        
        Args:
            packages: List of travel packages
            criteria: Filtering criteria
            
        Returns:
            Filtered list of packages
        """
        filtered_packages = packages
        
        # Filter by max price
        if 'max_price' in criteria and criteria['max_price']:
            max_price = float(criteria['max_price'])
            filtered_packages = [p for p in filtered_packages if p.get('total_price', float('inf')) <= max_price]
        
        # Filter by airline
        if 'airline' in criteria and criteria['airline']:
            airline = criteria['airline'].upper()
            filtered_packages = [
                p for p in filtered_packages 
                if any(
                    segment.get('carrierCode', '').upper() == airline 
                    for itinerary in p.get('flight', {}).get('itineraries', []) 
                    for segment in itinerary.get('segments', [])
                )
            ]
        
        # Filter by hotel rating
        if 'min_hotel_rating' in criteria and criteria['min_hotel_rating']:
            min_rating = float(criteria['min_hotel_rating'])
            
            def hotel_meets_rating(package):
                if 'hotel' in package:
                    # Single destination
                    rating = package.get('hotel', {}).get('hotel', {}).get('rating', 0)
                    try:
                        return float(rating) >= min_rating
                    except (ValueError, TypeError):
                        return False
                else:
                    # Multi-destination
                    hotels = package.get('hotels', [])
                    if not hotels:
                        return False
                    
                    for hotel in hotels:
                        rating = hotel.get('offers', [{}])[0].get('hotel', {}).get('rating', 0)
                        try:
                            if float(rating) < min_rating:
                                return False
                        except (ValueError, TypeError):
                            return False
                    
                    return True
            
            filtered_packages = [p for p in filtered_packages if hotel_meets_rating(p)]
        
        logger.info(f"Filtered packages from {len(packages)} to {len(filtered_packages)} based on criteria")
        return filtered_packages
